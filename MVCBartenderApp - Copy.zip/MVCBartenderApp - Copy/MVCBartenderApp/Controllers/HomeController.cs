﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations; //This makes the validation REQUIRED down there
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCBartenderApp.Controllers
{
    public class HomeController : Controller
    {
        private static IList<Drink> drinks = new List<Drink> //List of Comments
        {
        };

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Drinks()
        {
            return View(drinks);//tied to the Comments.cshtml, passed in 
        }

        public ActionResult AddDrink() //tied to AddComment.cshtml, passed in
        {
            return View();
        }

        [HttpPost] //everytime you do a post you have to do a redirect
        public ActionResult AddDrink(DrinkInput input) //Receive the model of the View
        {
            if (!ModelState.IsValid) //if it is not valid
            {
                return View(input); //if not valid return with the current model
            }

            drinks.Add(new Drink { Text = input.Text }); //adds the input

            return RedirectToAction("Drinks"); //everytime you do a post you have to do a redirect
        }

    }

    public class Foo //called in Index.cshtml
    {
        public string Name { get; set; } //called in Index.csHTML 
        public int Quantity { get; set; } //called in Index.csHTML value is 123
    }

    public class Drink
    {
        public string Text { get; set; }
    }

    public class DrinkInput //tied to the AddComment View
    {
        [Required]
        public string Text { get; set; }
    }
}